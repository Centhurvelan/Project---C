export const API_BASE_URL = "http://localhost:3002";

export const MESSAGES = {
    INVALID_CREDENTIALS : "Invalida Credentials",
    LOGIN_SUCCESS : "Logged in Successfull",
    GENERIC_ERROR : "Genric Error",
};